import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { defaultProject } from '/workspace/sites/highway-swap-station-sim/packages/reference/index.ts';
import { simulate } from '/workspace/sites/highway-swap-station-sim/packages/station-engine/index.ts';

// Read-only simulation audit: all project mutations are in memory.
// Expected values below are analytical physical timelines, not implementation assertions.
function blank() {
  const p = defaultProject();
  p.mode = 'CONSTRAINED';
  for (const s of ['A', 'B']) {
    p.station[s].auxiliaryKW = 0;
    p.station[s].guns = 1;
    p.station[s].gunKW = 480;
    p.station[s].chargePoolKW = 480;
  }
  for (const r of p.services) {
    r.swapCount = 0; r.swapKWh = 0;
    r.chargeCount = 0; r.chargeKWh = 0;
    r.gridPrice = 0; r.swapFee = 1; r.chargeFee = 1;
  }
  return p;
}
const row = (p, hour) => p.services.find(r => r.station === 'A' && r.hour === hour);
const results = [];

for (const count of [1, 1000]) {
  const p = blank();
  row(p, 0).chargeCount = count;
  row(p, 0).chargeKWh = count;
  const r = simulate(p);
  results.push({
    case: count === 1 ? 'single-small-charge' : 'small-charge-backlog',
    setup: { count, kWhPerJob: 1, gunKW: 480, guns: 1, arrivalWindowMinutes: 60 },
    expected: { firstCompletion: 0.125, finalCompletion: count === 1 ? 0.125 : 125 },
    actual: {
      firstTransactions: r.transactions.slice(0, 4), lastTransaction: r.transactions.at(-1),
      completedPerHour: r.hours.filter(h => h.station === 'A' && h.chargeCount).map(h => ({ hour: h.hour, count: h.chargeCount, energy: h.deliveredKWh, queue: h.queue })),
      totals: r.totals,
    },
  });
}

{
  const p = blank();
  p.station.A = { ...p.station.A, batteries: 1, capacityKWh: 100, readySOC: 1, returnSOC: 0, batteryChargeKW: 30 };
  row(p, 0).swapCount = 2; row(p, 0).swapKWh = 200;
  const r = simulate(p);
  results.push({ case: 'battery-ready-event', setup: { batteryKWh: 100, batteryChargeKW: 30, firstSwapCompletion: 7.5 }, expected: { secondSwapStart: 207.5, secondSwapCompletion: 215 }, actual: { transactions: r.transactions, totals: r.totals } });
}

{
  const p = blank();
  row(p, 0).chargeCount = 1000; row(p, 0).chargeKWh = 1000;
  for (const r of p.services) r.chargeFee = r.hour === 0 ? 1 : 10;
  const r = simulate(p);
  results.push({ case: 'charge-event-timing-tariff', setup: { count: 1000, kWhPerJob: 1, gunKW: 480, hour0ChargeFee: 1, laterChargeFee: 10, gridPrice: 0 }, expected: { hour0DeliveredKWh: 480, revenue: 480 * 1 + 520 * 10, finalCompletion: 125 }, actual: { hour0DeliveredKWh: r.hours.find(h => h.station === 'A' && h.hour === 0).deliveredKWh, revenue: r.totals.revenue, finalCompletion: r.transactions.at(-1).completion, maxBalanceResidual: r.totals.maxBalanceResidual } });
}

{
  const p = blank();
  p.station.A.swapMinutes = 60;
  row(p, 0).swapCount = 1; row(p, 0).swapKWh = 410; row(p, 1).swapFee = 2;
  const r = simulate(p);
  results.push({ case: 'exact-hour-swap-completion', expectedPolicy: 'Half-open hourly bins [hour:00, hour+1:00), docs/MASTER_PROMPT.md:3602; tariff expectation assumes completion-time billing.', expected: { completionHour: 1, revenue: 820 }, actual: { transactions: r.transactions, hours: r.hours.filter(h => h.station === 'A' && h.hour < 2), revenue: r.totals.revenue } });
}

{
  const p = blank();
  row(p, 0).swapCount = 1; row(p, 0).swapKWh = 409;
  row(p, 1).swapCount = 1; row(p, 1).swapKWh = 410;
  const r = simulate(p);
  results.push({ case: 'mismatched-swap-head-of-line', expectedPolicy: 'Incompatible requests remain unserved; a later compatible request can use available resources if incompatible requests are quarantined.', expected: { validSwapStart: 60, validSwapCompletion: 67.5 }, actual: { transactions: r.transactions, totals: r.totals, diagnostics: r.diagnostics.filter(d => d.code === 'SWAP_ENERGY_MISMATCH') } });
}

const output = fileURLToPath(new URL('./event-repro-output.json', import.meta.url));
writeFileSync(output, JSON.stringify({ generatedAt: new Date().toISOString(), engineVersion: '0.2.0', results }, null, 2) + '\n');
console.log(JSON.stringify({ output, cases: results.map(r => r.case) }));
