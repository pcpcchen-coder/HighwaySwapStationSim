import fs from 'node:fs';
import {defaultProject} from '/workspace/sites/highway-swap-station-sim/packages/reference/index.ts';
import {cashflow,npv} from '/workspace/sites/highway-swap-station-sim/packages/economics-engine/index.ts';
const p=defaultProject();Object.assign(p.finance,{capex:1000,fixedDaily:119,variablePerKWh:0,discountRate:.1,years:10,rampMonths:120,startLoad:0,operatingDaysPerYear:360});
const r=cashflow(p,120,0,0);
const scaledNpv=(rate)=>r.flows.reduce((sum,flow)=>sum*(1+rate)+flow,0);
let lo=-.999,hi=0;for(let i=0;i<120;i++){const mid=(lo+hi)/2;if(scaledNpv(mid)>0)lo=mid;else hi=mid;}const independentRoot=(lo+hi)/2;
const report={modelAnnualIrr:r.irr,modelIrrStatus:r.irrStatus,modelMonth1:r.rows[0],modelMonth119:r.rows[118],modelMonth120:r.rows[119],npvAtClaimedMonthlyRoot:npv(r.flows,(1+r.irr)**(1/12)-1),npvLowerEndpoint:String(npv(r.flows,-.999)),independentMonthlyRoot:independentRoot,independentAnnualRoot:(1+independentRoot)**12-1,scaledNpvAtIndependentRoot:scaledNpv(independentRoot)};
fs.writeFileSync('/workspace/scratch/75e090c675fe/audit/irr-reproduction.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
