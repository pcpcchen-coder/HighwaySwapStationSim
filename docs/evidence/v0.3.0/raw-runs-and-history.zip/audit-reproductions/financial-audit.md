# Financial audit — 2026-09-08

Read-only review of the initial engine 0.2.0 checkout; proposed replacement is in scratch only. No checkout files changed by this auditor.

## Confirmed findings

1. **Critical IRR false positive.** Valid inputs can cause `npv(flows,-.999)` to evaluate `-Infinity + Infinity = NaN`, bypass the root bracket checks and converge to monthly 1 with status `ok`. Repro: CAPEX 1000, daily fixed cost 119, daily receipts 120, energy cost 0, 10 years, ramp 120 months, start load 0, 360 operating days/year. Current annual IRR 4095 (409,500%); independent bounded polynomial root is monthly -0.5, annual -0.999755859375. NPV at claimed monthly root is -4510, so it cannot be a root.
2. **Multi-day state absent in original.** `simulate` stops at 1440, initializes full batteries every call, and truncates hourly lookup at 23. Repeating three one-day calls is not a continuous three-day simulation. In a no-supply, one-active-pack fixture, three calls deliver 300 kWh despite only 100 kWh available initially. New continuation horizon must carry batteries, queues, reserved swaps and charging sessions through midnight.
3. **Fixed auxiliary costs incorrectly scaled by traffic ramp.** With 10 kW auxiliary load, flat .5 CNY/kWh, full daily cost is 120. In a 30-day month this is 3600 even without customers. Original 1/12 ramp yields 300, understating cost by 3300. Fixed operating auxiliary cost must be separated from traffic-dependent electricity.
4. **Invalid inventory repair estimate.** Original uses combined `1-loss/grid` and combined mean grid price, which mixes ideal auxiliary circuits with battery recharge circuits. A 100-kWh deficit, battery efficiency .5, flat tariff .5 needs 100 CNY to repair; when the observed run has only 240 kWh of ideal auxiliary consumption, original estimates 50. Future repair tariff and feasible recharge schedule are not measured by this formula. Agreed remedy: block investment extrapolation if deficit >.01 kWh; retain observed cash contribution and inventory warning, with no invented repair expense or COGS.
5. **Snapshot mixing.** FinancePanel calls investmentCase(current draft, previous run) and receives a forecast combining current draft finance with previous operational totals. Changing fixedDaily from 0 to 100 changes projected month-one fixed cost to 3000 while snapshot remains 0. Use the immutable result parameter snapshot and refuse mismatched arguments.
6. **Undefined transaction tariff anchor.** Swap billing uses completion time minus epsilon; a swap completing exactly minute 60 gets hour-0 tariff while a slightly delayed completion gets hour-1 tariff. This is not consistent arrival locking. Adopt and persist arrival unitPrice per transaction; charging partial-period invoices must use that price after midnight too. Historical SOURCE_REPLAY remains separate source arithmetic.
7. **Missing monetary settlement policy.** Original bills with binary floating `number` and only formats the display. Ten 1-kWh invoices at 1.005 produce unrounded total 10.05; half-up per-invoice settlement requires 10.10. Agreed new policy from root: CNY half-up cents, 6-decimal kWh/rates, source-hour purchase invoices and per-session delivered invoices, with deterministic cent apportionment. Cents must reconcile exactly to an independent Decimal oracle.
8. **Source attribution distinction.** Original purchase tariff uses the correct `sourceImport` source station. A B load receiving 100 kWh from A at .25 has correct cost 25, even if B local grid rate is 1. However hourly `gridKWh` and `gridCost` are attributed to consuming station B rather than buying source meter A. They are a load-allocation ledger; a separate meter ledger is needed for source-meter claims.

## Prepared correction

`packages/economics-engine/index.ts` under this audit directory is a drop-in proposed module. It preserves bill/breakEven/npv/irr/payback/cashflow/investmentCase exports. Added fields are backward compatible. `cashflow` takes optional fifth input `dailyFixedEnergyCost` included within `dailyEnergyCost`.

- Stable, normalized Horner evaluation handles long negative-rate cash flows without Infinity cancellation; no invalid bracket products.
- investmentCase rejects draft/snapshot mismatch and normalizes all observed multi-day quantities by horizonDays.
- Fixed auxiliary electricity is outside traffic ramp; row fields explain fixed/variable electricity and non-energy costs.
- Deficit inventory blocks forecast and sets ENDING_INVENTORY_INCOMPLETE.
- Observed energyContribution = revenue - gridCost.
- Observed modeledOperatingContribution = revenue - gridCost - variablePerKWh * deliveredKWh - fixedDaily * horizonDays, only when fixedDaily known.
- Accounting profit remains null: opening and closing inventory cost valuation is not modeled.
- Missing CAPEX/fixedDaily blocks investment forecast. Complete supplied inputs still carry ASSUMPTION_BASED_PROJECTION status.

Eight focused regression tests passed via `node --test audit/economics-regression.test.ts`: pathological IRR, reference NPV/IRR/payback, deep negative IRR, 1/3/5-day normalization invariance, fixed auxiliary ramp, fixed/variable row bridge, snapshot refusal, inventory block, missing costs and zero-grid losses. Some test assertions are grouped in one test.

## Acceptance and interpretation

Three independently computed scenarios are evidence of the tested model and declared assumptions. They do not prove 100% predictive accuracy for an actual site. Distinguish:

- physical output: energy conservation, source-meter limits, battery inventory state, completed/deferred services;
- money arithmetic: exact cent settlement from declared quantities and prices;
- observed cash operating contribution: cash receipts less modeled cash expenses;
- accounting profit: requires inventory acquisition costs, depreciation/taxes and complete accounting policies;
- investment return: requires verified CAPEX, operating costs, demand/price history, replacement schedules, working capital, calendar and financing assumptions.

The primary model scope remains a deterministic, simplified power allocator with configurable efficiencies and auxiliary load factors. No battery degradation/temperature charging curve, calibrated real arrival forecast, complete asset replacement/tax model or validated actual site tariff contract is established by these tests.
