import {defaultProject,presetTopology} from '/workspace/sites/highway-swap-station-sim/packages/reference/index.ts';
import {engineeringProject} from '/workspace/sites/highway-swap-station-sim/packages/engineering/index.ts';
import {allocatePower} from '/workspace/sites/highway-swap-station-sim/packages/electrical-engine/index.ts';
import {validateTopology} from '/workspace/sites/highway-swap-station-sim/packages/topology-engine/index.ts';
import {makeNode} from '/workspace/sites/highway-swap-station-sim/plugins/equipment/index.ts';
let p=engineeringProject();p.topology={nodes:[makeNode('grid','grid','A',0,0,{kva:100,pf:1}),makeNode('sst','sst','A',0,0,{kw:100})],edges:[]};
for(let i=0;i<65;i++){p.topology.nodes.push(makeNode('mv-switch',`branch-${i}`,'A',0,0,{kw:i===64?100:0}));p.topology.edges.push({id:`in-${i}`,source:'grid',target:`branch-${i}`,enabled:true},{id:`out-${i}`,source:`branch-${i}`,target:'sst',enabled:true});}
console.log('SILENT-PATH-LIMIT',{errors:validateTopology(p.topology),allocation:allocatePower(p,[{sink:'sst',kw:98}])});
p.topology.edges.reverse();console.log('PATH-REVERSE',{errors:validateTopology(p.topology),allocation:allocatePower(p,[{sink:'sst',kw:98}])});
p=engineeringProject();p.topology={nodes:[makeNode('grid','A-grid','A',0,0,{kva:100,pf:1}),makeNode('grid','B-grid','B',0,0,{kva:100,pf:1}),makeNode('sst','flex','A',0,0,{kw:200}),makeNode('sst','restricted','A',0,0,{kw:200})],edges:[{id:'af',source:'A-grid',target:'flex',enabled:true},{id:'bf',source:'B-grid',target:'flex',enabled:true},{id:'ar',source:'A-grid',target:'restricted',enabled:true}]};
console.log('GREEDY-STARVATION',{errors:validateTopology(p.topology),allocation:allocatePower(p,[{sink:'flex',kw:98},{sink:'restricted',kw:98}])});console.log('GREEDY-REVERSED',{allocation:allocatePower(p,[{sink:'restricted',kw:98},{sink:'flex',kw:98}])});
p=defaultProject();p.topology=presetTopology(1,'sst');p.efficiency.mode='SOURCE_CHAIN';console.log('SOURCE-CHAIN-SST-OUTPUT',{allocation:allocatePower(p,[{sink:'A-charger',kw:2000}])});p.efficiency.mode='ASSEMBLY';console.log('ASSEMBLY-SST-OUTPUT',{allocation:allocatePower(p,[{sink:'A-charger',kw:2000}])});
